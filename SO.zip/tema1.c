#include <stdlib.h>
#include <string.h>
#include <stdio.h>

struct list{
    int ok;
    char *key;
    char *val;
    struct list *next;
};

struct map{
    int size;
    struct list **lists;
};

struct map *Create_Map(int size){
    int i;
    struct map *m = (struct map *)malloc(sizeof(struct map));

    m->size = size;
    m->lists = (struct list **)malloc(sizeof(struct list *) * size);

    for(i = 0; i < size; i++){
        m->lists[i] = NULL;
    }

    return m;
}

int Hash_Func(char *key){
    int position = (int)key[0];

    return position;
}

void add(struct map *m, char *key, char *val){
    int position = Hash_Func(key);
    struct list *aux = m->lists[position];
    struct list *new = (struct list *)malloc(sizeof(struct list));

    while(aux != NULL){
        if(strcmp(aux->key, key) == 0){
            return;
        }
        aux = aux->next;
    }

    aux = m->lists[position];

    new->key = (char*)malloc(sizeof(char) * 100);
    new->val = (char*)malloc(sizeof(char) * 100);
    new->ok = 0;
    

    strcpy(new->key, key);
    strcpy(new->val, val);
    new->next = aux;
    m->lists[position] = new;
}

char *val_of(struct map *m, char *key){
    int position = Hash_Func(key);
    struct list *aux = m->lists[position];

    while (aux != NULL){
        if(strcmp(key, aux->key) == 0){
            break;
        }
        aux = aux->next;
    }

    if(aux == NULL){
        return "Nu";
    }

    return aux->val;
}

int ok_of(struct map *m, char *key){
    int position = Hash_Func(key);
    struct list *aux = m->lists[position];

    while(aux != NULL){
        if(strcmp(key, aux->key) == 0){
            break;
        }
        aux = aux->next;
    }

    if(aux == NULL){
        return -1;
    }

    return aux->ok;
}

void inc_ok(struct map *m, char *key){
    int position = Hash_Func(key);
    struct list *aux = m->lists[position];

    while(aux != NULL){
        if(strcmp(key, aux->key) == 0){
            break;
        }
        aux = aux->next;
    }

    if(aux == NULL){
        return;
    }

    aux->ok++;
}

void dec_ok(struct map *m){
   int i;
   struct list *aux;

   for(i = 0; i < m->size; i++){
       aux = m->lists[i];
       while(aux != NULL){
           aux->ok = 0;
           aux = aux->next;
       }
   }
}

int empty(struct map *m){
    int i;

    for(i = 0; i < m->size; i++){
        if(m->lists[i] != NULL){
            return 0;
        }
    }
    return 1;
}

int contains(struct map *m, char *key){
    struct list *aux = m->lists[Hash_Func(key)];

    while(aux != NULL){
        if(strcmp(aux->key, key) == 0){
            return 1;
        }
    }

    return 0;
}

void define(struct map *m, char *file){
    char *key = (char*)malloc(sizeof(char) * 20);
    char *val = (char*)malloc(sizeof(char) * 20);
    char *aux = (char*)malloc(sizeof(char) * 100);
    int i = 0;
    int n = 0;
    int k = 0;
    int x = 0;

    while (file[i] != '\n'){
        aux[i] = file[i];
        i++;
    }

    strcpy(key, strtok(aux, " "));
    strcpy(key, strtok(NULL, " "));
    
    for(i = 0; i < strlen(file); i++){
        if(file[i] == 92){
            if(x == 0){
                x++;
                k--;
            }
            i += 8;
            
            continue;
        }

        if(file[i] == '\n'){
            break;
        }
        
        if(file[i] == ' ' && n < 2){
            n++;
            continue;
        }
        
        if(n >= 2){
            val[k] = file[i];
            k++;
        }
    }

    val[k] = '\0';

    add(m, key, val);
    free(key);
    free(val);
    free(aux);
}

void check_for_directive(struct map *m, char *file){
    int i;
    int l = strlen(file);

    for(i = 0; i < l; i++){
        if(file[i] == '#'){
            if(strncmp(file + i, "#define", 7) == 0){
                define(m, file + i);
            }
        }
    }
}

void undef(struct list **list, char *key){
    struct list *aux = (*list);

    if(strcmp(key, aux->key) == 0){
        (*list) = (*list)->next;
    }else{
        while(strcmp(aux->next->key, key) != 0){
            aux = aux->next;
        }
        aux->next = aux->next->next;
    }
}

void resolve_define(struct map *m, char *file){
    int i, j, k = 0;
    int x = 0;
    int diez = 0;
    int undef_bool = 0;
    char *aux = (char*)malloc(sizeof(char) * 200);
    char *val = (char*)malloc(sizeof(char) * 200);
    char *rez = (char*)malloc(sizeof(char) * 2000);
    char *a = (char*)malloc(sizeof(char) * 2000);
    
    strcpy(rez, "");

    strcpy(a, file);

    for(i = 0; i < strlen(a); i++){
        if(a[i] == '#'){
            diez = 1;
        }

        if(a[i] == '\n'){
            diez = 0;
        }

        if(a[i] == ' '  || a[i] == ';'
        || a[i] == ')' || a[i] == ']' || a[i] == '\n'){
            aux[k] = '\0';
            if(strcmp(aux, "#undef") == 0 || strcmp(aux, "undef") == 0){
                undef_bool=1;
            }
            if(strlen(aux) > 0){
                strcpy(val, val_of(m, aux));
                x = 0;
                if(strcmp(val, "Nu") != 0){
                    if(undef_bool == 1){
                        undef(&m->lists[Hash_Func(aux)], aux);
                    }
                    strcpy(rez, "");
                    if(diez == 1){
                        inc_ok(m, aux);
                        continue;
                    }

                    for(j  = 0; j < i - strlen(aux); j++){
                        rez[x] = a[j];
                        x++;
                    }
                    for(j = 0; j < strlen(val); j++){
                        rez[x] = val[j];
                        x++;
                    }
                    for(j = i; j < strlen(a); j++){
                        rez[x] = a[j];
                        x++;
                    }
                    rez[x] = '\0';

                    strcpy(a, "\0");
                    strcpy(a, rez);
                }
                
                k = 0;
                continue;
            }
        }

        aux[k] = a[i];
        k++;
    }
    free(aux);
    free(val);
    free(a);
    strcpy(file, rez);
    free(rez);
}

int mark_line(char *file){
    int i = 1;

    while(file[i] != '#'){
        if(file[i] == '\n' && file[i+1] != '#'){
            file[i+1] = '#';
            i++;
        }
        i++;
    }

    return i;
}

void if_directive(char *file, int cond){
    int i;
    int j = 0;
    char *ret;
    char *tok = (char*)malloc(sizeof(char) * 20);

    if(!cond){
        i = mark_line(file);
        ret = strstr(file + i, "#elif");
        if(ret != NULL){
            i = 0;
            while(ret[i] != ' '){
                i++;
            }
            i++;

            while(ret[i] != '\n'){
                tok[j] = ret[i];
                i++;
                j++;
            }
            tok[j] = '\0';

            cond = atoi(tok);
            if_directive(ret, cond);
        }
    }else{
        file = strstr(file, "#else");
        if(file != NULL){
            i = mark_line(file);
        }
    }

    free(tok);
}

void resolve_if(struct map *m, char *file){
    int i = 0;
    int j = 0;
    int cond = 0;
    char *ret = "";
    char *tok = (char*)malloc(sizeof(char) * 20);
    
    strcpy(tok, "");

    ret = strstr(file, "#if ");
    if(ret != NULL){

        i = 0;
        while(ret[i] != ' '){
            i++;
        }
        i++;

        while(ret[i] != '\n'){
            tok[j] = ret[i];
            i++;
            j++;
        }
        tok[j] = '\0';

        cond = atoi(tok);
        if_directive(ret, cond);
    }

    free(tok);
}

void ifdef_directive(struct map *m, char *file){
    int i = 0;
    int j = 0;
    char *ret = "";
    char *tok = (char*)malloc(sizeof(char) * 20);
   
    strcpy(tok, "");

    ret = strstr(file, "#ifdef");
    if(ret != NULL){

        i = 0;
        while(ret[i] != ' '){
            i++;
        }
        i++;

        while(ret[i] != '\n'){
            tok[j] = ret[i];
            i++;
            j++;
        }
        tok[j] = '\0';

        if(!contains(m, tok)){
            if_directive(ret, contains(m, tok));
        }
    }

    free(tok);
}

void resolve_directive(struct map *m, char *file){
    char *aux = (char*)malloc(sizeof(char)*2000);
    int gata = 0;
    
    strcpy(aux, "");

    ifdef_directive(m, file);

    if(!empty(m)){
        resolve_define(m, file);
        strcpy(aux, file);
        
        while(gata == 0){
            dec_ok(m);
            resolve_define(m, aux);
            check_for_directive(m, aux);
            if(strcmp(aux, "") == 0)
                break;
            strcpy(file, aux);
        }
    }
    
    resolve_if(m, file);

    free(aux);
}

void del_directive(char *file){
    int i, k = 0;;
    char rez[2000] = "";
    
    for(i = 0; i < strlen(file); i++){

        if(file[i] == '\n' && file[i-1] == '\n'){
            continue;
        }
        
        if((file[i] == '#' && i == 0) || (file[i] == '#' && file[i-1] == '\n')){
            while(1){
                i++;
                if(file[i] == '\n' &&file[i-1] != 92){
                    break;
                }
            }
            continue;
        }
        
        rez[k] = file[i];
        k++;
    }

    strcpy(file, rez);
}

void free_list(struct list **list){
    struct list *temp;

    while((*list) != NULL){
        temp = (*list);
        (*list) = (*list)->next;
        free(temp->key);
        free(temp->val);
        free(temp);
    }
}

void free_map(struct map *m){
    int i;
    
    for(i = 0; i < m->size; i++){
        if(m->lists[i] != NULL){
            free_list(&m->lists[i]);
        }
    }

    free(m->lists);
    free(m);
}

int main(int argc, char *argv[]){

    struct map *Map = Create_Map(200);
    int i, j, k = 0;
    int len;
    char *aux = (char*)malloc(sizeof(char)*20);
    char input_file[20] = "stdin";
    char output_file[20] = "stdout";
    char *header_dir = (char*)malloc(sizeof(char)*20);
    char *file = (char*)malloc(sizeof(char) * 2000);
    char *buf = (char*)malloc(sizeof(char) * 100);
    char fel[3] = "";
    char *tok1;
    char *tok2;
    FILE * input;
    FILE * out;

    strcpy(file, "");
    strcpy(header_dir, "");
    strcpy(aux, "");
    strcpy(buf, "");

    if(argc > 1){
        for(i = 1; i < argc; i++){
            len = strlen(argv[i]);
            if(strcmp(argv[i],"-D") == 0){
                i++;
                tok1 = strtok(argv[i], "=");
                tok2 = strtok(NULL, "=");
                if(tok2 == NULL)
                    tok2 = "";
                add(Map, tok1, tok2);

                continue;
            }

            if(strcmp(argv[i], "-I") == 0){
                i++;
                strcpy(header_dir, argv[i]);
                continue;
            }

            if(strcmp(argv[i],"-o") == 0){
                i++;
                strcpy(output_file, argv[i]);
                continue;
            }

            if(strncmp(argv[i], "-D", 2) == 0){
                tok1 = strtok(argv[i] + 2, "=");
                tok2 = strtok(NULL, "=");
                if(tok2 == NULL)
                    tok2 = "";
                add(Map, tok1, tok2);
                continue;
            }

            if(strncmp(argv[i], "-I", 2) == 0){
                strcpy(header_dir, argv[i] + 2);
                continue;
            }

            if(strncmp(argv[i], "-o", 2) == 0){
                strcpy(output_file, argv[i] + 2);
                continue;
            }

            strcpy(aux, input_file);
            strcpy(fel, (argv[i] + len - 3));
            strcpy(input_file, aux);

            if(strcmp(argv[i] + len - 3, "out") == 0){
                for(j = 0; j < len; j++){
                    output_file[k] = argv[i][j];
                    k++;
                }
                output_file[k] = '\0';
                continue;
            }
            
            if(strcmp(argv[i] + len - 3, ".in") == 0){
                k=0;
                 for(j = 0; j < len; j++){
                    input_file[k] = argv[i][j];
                    k++;
                }
                input_file[k] = '\0';
                continue;
            }
        }
    }

    if(strcmp(input_file, "stdin") != 0){
        input = fopen(input_file, "r");

        while(fgets(buf, 100, input)){
            strcat(file, buf);
        }
        fclose(input);
    }

    check_for_directive(Map, file);

    resolve_directive(Map, file);

    del_directive(file);

    if(strcmp(output_file, "stdout") == 0){
        printf("%s", file);
    }else{
        out = fopen(output_file, "w");
        fputs(file, out);
        fclose(out);
    }

    free(aux);
    free(header_dir);
    free(file);
    free(buf);
    free_map(Map);
}